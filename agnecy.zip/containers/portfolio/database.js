module.exports = {
  FeshionImgData: [
    {
      img: "/al-amana24.jpeg",
    },
    {
      img: "/arihas collection.jpeg",
    },
    {
      img: "/ayan fashion.jpeg",
    },
    {
      img: "/ben.rois.jpeg",
    },
  ],

  BagsImgData: [
    {
      img: "/chander konna.jpeg",
    },
    {
      img: "/creative creation.jpeg",
    },
    {
      img: "/emart.jpeg",
    },
    {
      img: "/food hatt.jpeg",
    },
  ],

  ShoesImgData: [
    {
      img: "/give & take.jpeg",
    },
    {
      img: "/hello guys.jpeg",
    },
    {
      img: "/home chef.jpeg",
    },
    {
      img: "/intex.jpeg",
    },
  ],

  WatchImgData: [
    {
      img: "/isha.jpeg",
    },
    {
      img: `/keya's beauty shop.jpeg`,
    },
    {
      img: "/kozzyby.jpeg",
    },
    {
      img: "/noor.jpeg",
    },
  ],

  AllImgData: [
    {
      img: "/triangle.jpeg",
    },
    {
      img: "/travel kites.jpeg",
    },
    {
      img: "/tati polli.jpeg",
    },
    {
      img: "/sony lite.jpeg",
    },
    {
      img: "/shutki bajar.jpeg",
    },
    {
      img: "/shirt e.jpeg",
    },
    {
      img: "/s.jpeg",
    },
    {
      img: "/rupoboti.jpeg",
    },
    {
      img: "/priyoo sohor b-bariya.jpeg",
    },
    {
      img: "/polli rokomari.jpeg",
    },
    {
      img: "/pink s.jpeg",
    },
    {
      img: "/one touch.jpeg",
    },
  ],
  PortfolioDetail1Data: [
    {
      img: "/assets/images/2.jpg",
    },
    {
      img: "/assets/images/3.jpg",
    },
    {
      img: "/assets/images/5.jpg",
    },
    {
      img: "/assets/images/4.jpg",
    },
    {
      img: "/assets/images/5.jpg",
    },
    {
      img: "/assets/images/2.jpg",
    },
    {
      img: "/assets/images/3.jpg",
    },
  ],

  CreativeWrapperData: [
    {
      img: "../assets/images/1.jpg",
      title: "Lorem Ipsum",
      desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      img: "../assets/images/2.jpg",
      title: "Lorem Ipsum",
      desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      img: "../assets/images/3.jpg",
      title: "Lorem Ipsum",
      desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      img: "../assets/images/4.jpg",
      title: "Lorem Ipsum",
      desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      img: "../assets/images/5.jpg",
      title: "Lorem Ipsum",
      desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
  ],
};
