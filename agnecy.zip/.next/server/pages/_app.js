"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 4221:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MyApp)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: external "nprogress"
const external_nprogress_namespaceObject = require("nprogress");
var external_nprogress_default = /*#__PURE__*/__webpack_require__.n(external_nprogress_namespaceObject);
;// CONCATENATED MODULE: external "next/config"
const config_namespaceObject = require("next/config");
var config_default = /*#__PURE__*/__webpack_require__.n(config_namespaceObject);
;// CONCATENATED MODULE: external "react-toastify"
const external_react_toastify_namespaceObject = require("react-toastify");
;// CONCATENATED MODULE: ./containers/customizer.js


const Customizer = ()=>{
    const { 0: divName1 , 1: setDivName  } = (0,external_react_.useState)('RTL');
    const { 0: themeLayout , 1: setThemeLayout  } = (0,external_react_.useState)(false);
    const ChangeRtl = (divName)=>{
        if (divName === 'RTL') {
            if (false) {}
            setDivName('LTR');
        } else {
            if (false) {}
            setDivName('RTL');
        }
    };
    const changeThemeLayout = ()=>{
        setThemeLayout(!themeLayout);
    };
    if (themeLayout) {
        if (false) {}
    } else {
        if (false) {}
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "theme-pannel-main",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    id: "rtl_btn",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: null,
                        className: "btn setting_btn",
                        onClick: ()=>ChangeRtl(divName1)
                        ,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "rtl-txt",
                            children: divName1
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: "sidebar-btn dark-light-btn",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: null,
                        className: "dark-light",
                        onClick: ()=>changeThemeLayout()
                        ,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "theme-layout-version",
                            children: themeLayout ? 'Light' : 'Dark'
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const customizer = (Customizer);

;// CONCATENATED MODULE: external "@apollo/client"
const client_namespaceObject = require("@apollo/client");
;// CONCATENATED MODULE: ./apollo-client.js

// Used server and client side - can't use react hooks
const client = new client_namespaceObject.ApolloClient({
    cache: new client_namespaceObject.InMemoryCache(),
    link: new client_namespaceObject.HttpLink({
        uri: 'http://localhost:3000/api/graphql'
    }),
    ssrMode: "undefined" === 'undefined'
});
/* harmony default export */ const apollo_client = (client);

;// CONCATENATED MODULE: ./pages/_app.js











const { publicRuntimeConfig ={}  } = config_default()() || {};
external_nprogress_default().configure({
    showSpinner: publicRuntimeConfig.NProgressShowSpinner
});
(router_default()).onRouteChangeStart = ()=>{
    external_nprogress_default().start();
};
(router_default()).onRouteChangeComplete = ()=>{
    external_nprogress_default().done();
};
(router_default()).onRouteChangeError = ()=>{
    external_nprogress_default().done();
};
function MyFunctionComponent({ children  }) {
    const { 0: loader , 1: setLoader  } = (0,external_react_.useState)(true);
    const { 0: goingUp , 1: setGoingUp  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        // Page Loader
        setTimeout(()=>{
            setLoader(false);
        }, 1500);
        // Tap to Top Scroll 
        const handleScroll = ()=>{
            const currentScrollY = window.scrollY;
            if (currentScrollY > 500) setGoingUp(true);
            else setGoingUp(false);
        };
        window.addEventListener("scroll", handleScroll, {
            passive: true
        });
        return ()=>window.removeEventListener("scroll", handleScroll)
        ;
    }, [
        goingUp
    ]);
    const tapToTop = ()=>{
        window.scrollTo({
            behavior: "smooth",
            top: 0
        });
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(client_namespaceObject.ApolloProvider, {
            client: apollo_client,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Boosting BD"
                    })
                }),
                loader && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "loader-wrapper",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "loader",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "tap-top",
                    style: goingUp ? {
                        display: 'block'
                    } : {
                        display: 'none'
                    },
                    onClick: tapToTop,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-angle-double-up"
                        })
                    })
                })
            ]
        })
    }));
}
function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MyFunctionComponent, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(customizer, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_toastify_namespaceObject.ToastContainer, {})
        ]
    }));
};


/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4221));
module.exports = __webpack_exports__;

})();