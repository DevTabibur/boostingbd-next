"use strict";
(() => {
var exports = {};
exports.id = 1702;
exports.ids = [1702];
exports.modules = {

/***/ 3443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ graphql)
});

;// CONCATENATED MODULE: external "micro-cors"
const external_micro_cors_namespaceObject = require("micro-cors");
var external_micro_cors_default = /*#__PURE__*/__webpack_require__.n(external_micro_cors_namespaceObject);
;// CONCATENATED MODULE: external "apollo-server-micro"
const external_apollo_server_micro_namespaceObject = require("apollo-server-micro");
;// CONCATENATED MODULE: ./graphql/resolver.js
const resolvers = {
    Query: {
        blogs (parent, args, context) {
            return [
                {
                    id: 1,
                    image: "/assets/images/agency/blog/12.jpg",
                    place: "Phonics ,Newyork",
                    title: "Twice profit than before you",
                    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                    readUrl: "#",
                    likes: 10,
                    comments: 20,
                    createdAt: "01-01-2022",
                    createdBy: "MARK JKCNO"
                },
                {
                    id: 2,
                    image: "/assets/images/agency/blog/10.jpg",
                    place: "Phonics ,Newyork",
                    title: "Twice profit than before you",
                    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                    readUrl: "#",
                    likes: 10,
                    comments: 20,
                    createdAt: "01-01-2022",
                    createdBy: "MARK JKCNO"
                },
                {
                    id: 3,
                    image: "/assets/images/agency/blog/11.jpg",
                    place: "Phonics ,Newyork",
                    title: "Twice profit than before you",
                    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                    readUrl: "#",
                    likes: 10,
                    comments: 20,
                    createdAt: "01-01-2022",
                    createdBy: "MARK JKCNO"
                },
                {
                    id: 4,
                    image: "/assets/images/agency/blog/14.jpg",
                    place: "Phonics ,Newyork",
                    title: "Twice profit than before you",
                    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                    readUrl: "#",
                    likes: 10,
                    comments: 20,
                    createdAt: "01-01-2022",
                    createdBy: "MARK JKCNO"
                },
                {
                    id: 5,
                    image: "/assets/images/agency/blog/13.jpg",
                    place: "Phonics ,Newyork",
                    title: "Twice profit than before you",
                    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                    readUrl: "#",
                    likes: 10,
                    comments: 20,
                    createdAt: "01-01-2022",
                    createdBy: "MARK JKCNO"
                },
                {
                    id: 6,
                    image: "/assets/images/agency/blog/16.jpg",
                    place: "Phonics ,Newyork",
                    title: "Twice profit than before you",
                    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                    readUrl: "#",
                    likes: 10,
                    comments: 20,
                    createdAt: "01-01-2022",
                    createdBy: "MARK JKCNO"
                }, 
            ];
        }
    }
};
/* harmony default export */ const resolver = (resolvers);

;// CONCATENATED MODULE: ./graphql/typeDefs.js

const typeDefs = external_apollo_server_micro_namespaceObject.gql`
  type Query {
    blogs: [Blog!]!
  }
  type Blog {
    id: Int
    title: String
    image: String
    place:String
    description: String
    readUrl: String
    likes: String
    comments: String
    createdAt: String
    createdBy: String
  }
`;
/* harmony default export */ const graphql_typeDefs = (typeDefs);

;// CONCATENATED MODULE: ./pages/api/graphql.js




const cors = external_micro_cors_default()({
    origin: "https://studio.apollographql.com",
    allowCredentials: true
});
const apolloServer = new external_apollo_server_micro_namespaceObject.ApolloServer({
    typeDefs: graphql_typeDefs,
    resolvers: resolver
});
const startServer = apolloServer.start();
/* harmony default export */ const graphql = (cors(async (req, res)=>{
    if (req.method === "OPTIONS") {
        res.end();
        return false;
    }
    await startServer;
    await apolloServer.createHandler({
        path: "/api/graphql"
    })(req, res);
}));
// // Apollo Server Micro takes care of body parsing
const config = {
    api: {
        bodyParser: false
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3443));
module.exports = __webpack_exports__;

})();