"use strict";
exports.id = 2386;
exports.ids = [2386];
exports.modules = {

/***/ 2306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7910);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);




const AllImgFun = ({ className , title , subTitle  })=>{
    const initilindex = {
        index: 0,
        isOpen: false
    };
    const { 0: photoIndex , 1: setPhotoIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initilindex);
    const onClickImg = (img, i)=>{
        setPhotoIndex({
            ...photoIndex,
            index: i,
            image: img,
            isOpen: true
        });
    };
    const onMoveNext = ()=>{
        const next = (photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: next,
            image: test.img
        });
    };
    const onMovePrev = ()=>{
        const prev = (photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: prev,
            image: test.img
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length > 0 ? _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: className,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "overlay",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-portfolio",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "overlay-background",
                                        onClick: ()=>onClickImg(item.img, i)
                                        ,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            "aria-hidden": "true",
                                            className: "fa fa-plus"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        alt: "",
                                        className: "img-fluid blur-up lazyload",
                                        src: `/assets/images/${item.img}`
                                    })
                                ]
                            })
                        }),
                        title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "portfolio-text",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "head-text",
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "head-sub-text",
                                    children: subTitle
                                })
                            ]
                        })
                    ]
                }, i)
            ) : "",
            photoIndex.isOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    console.log("${AllImgData[(photoIndex.index + 1) % AllImgData.length]}", _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length].img),
                    console.log("Image", photoIndex.image, "========", `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.AllImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length].img}`),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default()), {
                        mainSrc: `/assets/images${photoIndex.image}`,
                        nextSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.AllImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length].img}`,
                        prevSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.AllImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length].img}`,
                        imageTitle: photoIndex.index + 1 + "/" + _database__WEBPACK_IMPORTED_MODULE_2__.AllImgData.length,
                        onCloseRequest: ()=>setPhotoIndex({
                                ...photoIndex,
                                isOpen: false
                            })
                        ,
                        onMovePrevRequest: onMovePrev,
                        onMoveNextRequest: onMoveNext
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllImgFun);


/***/ }),

/***/ 9133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7910);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);




const BagsImgFunc = ({ className , title , subTitle  })=>{
    const initilindex = {
        index: 0,
        isOpen: false
    };
    const { 0: photoIndex , 1: setPhotoIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initilindex);
    const onClickImg = (img, i)=>{
        setPhotoIndex({
            ...photoIndex,
            index: i,
            image: img,
            isOpen: true
        });
    };
    const onMovePrev = ()=>{
        const prev = (photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: prev,
            image: test.img
        });
    };
    const onMoveNext = ()=>{
        const next = (photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: next,
            image: test.img
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length > 0 ? _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: className,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "overlay",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-portfolio",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "overlay-background",
                                        onClick: ()=>onClickImg(item.img, i)
                                        ,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            "aria-hidden": "true",
                                            className: "fa fa-plus"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        alt: "",
                                        className: "img-fluid blur-up lazyload",
                                        src: `/assets/images/${item.img}`
                                    })
                                ]
                            })
                        }),
                        title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "portfolio-text",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "head-text",
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "head-sub-text",
                                    children: subTitle
                                })
                            ]
                        })
                    ]
                }, i)
            ) : "",
            photoIndex.isOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default()), {
                mainSrc: `/assets/images${photoIndex === null || photoIndex === void 0 ? void 0 : photoIndex.image}`,
                nextSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length].img}`,
                prevSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length].img}`,
                imageTitle: photoIndex.index + 1 + "/" + _database__WEBPACK_IMPORTED_MODULE_2__.BagsImgData.length,
                onCloseRequest: ()=>setPhotoIndex({
                        ...photoIndex,
                        isOpen: false
                    })
                ,
                onMovePrevRequest: onMovePrev,
                onMoveNextRequest: onMoveNext
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BagsImgFunc);


/***/ }),

/***/ 2199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7910);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);




const FashionImgFunc = ({ className , title , subTitle  })=>{
    const initilindex = {
        index: 0,
        isOpen: false
    };
    const { 0: photoIndex , 1: setPhotoIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initilindex);
    const onClickImg = (img, i)=>{
        setPhotoIndex({
            ...photoIndex,
            index: i,
            image: img,
            isOpen: true
        });
    };
    const onMovePrev = ()=>{
        const prev = (photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: prev,
            image: test.img
        });
    };
    const onMoveNext = ()=>{
        const next = (photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: next,
            image: test.img
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length > 0 ? _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: className,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "overlay",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-portfolio",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "overlay-background",
                                        onClick: ()=>onClickImg(item.img, i)
                                        ,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            "aria-hidden": "true",
                                            className: "fa fa-plus"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        alt: "",
                                        className: "img-fluid blur-up lazyload",
                                        src: `/assets/images/${item.img}`
                                    })
                                ]
                            })
                        }),
                        title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "portfolio-text",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "head-text",
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "head-sub-text",
                                    children: subTitle
                                })
                            ]
                        })
                    ]
                }, i)
            ) : "",
            photoIndex.isOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default()), {
                mainSrc: `/assets/images${photoIndex === null || photoIndex === void 0 ? void 0 : photoIndex.image}`,
                nextSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length].img}`,
                prevSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length].img}`,
                imageTitle: photoIndex.index + 1 + "/" + _database__WEBPACK_IMPORTED_MODULE_2__.FeshionImgData.length,
                onCloseRequest: ()=>setPhotoIndex({
                        ...photoIndex,
                        isOpen: false
                    })
                ,
                onMovePrevRequest: onMovePrev,
                onMoveNextRequest: onMoveNext
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FashionImgFunc);


/***/ }),

/***/ 2970:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7910);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);




const ShoesImgFun = ({ className , title , subTitle  })=>{
    const initilindex = {
        index: 0,
        isOpen: false
    };
    const { 0: photoIndex , 1: setPhotoIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initilindex);
    const onClickImg = (img, i)=>{
        setPhotoIndex({
            ...photoIndex,
            index: i,
            image: img,
            isOpen: true
        });
    };
    const onMoveNext = ()=>{
        const next = (photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: next,
            image: test.img
        });
    };
    const onMovePrev = ()=>{
        const prev = (photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: prev,
            image: test.img
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length > 0 ? _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: className,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "overlay",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-portfolio",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "overlay-background",
                                        onClick: ()=>onClickImg(item.img, i)
                                        ,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            "aria-hidden": "true",
                                            className: "fa fa-plus"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        alt: "",
                                        className: "img-fluid blur-up lazyload",
                                        src: `/assets/images/${item.img}`
                                    })
                                ]
                            })
                        }),
                        title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "portfolio-text",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "head-text",
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "head-sub-text",
                                    children: subTitle
                                })
                            ]
                        })
                    ]
                }, i)
            ) : "",
            photoIndex.isOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default()), {
                mainSrc: `/assets/images${photoIndex === null || photoIndex === void 0 ? void 0 : photoIndex.image}`,
                nextSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length].img}`,
                prevSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length].img}`,
                imageTitle: photoIndex.index + 1 + "/" + _database__WEBPACK_IMPORTED_MODULE_2__.ShoesImgData.length,
                onCloseRequest: ()=>setPhotoIndex({
                        ...photoIndex,
                        isOpen: false
                    })
                ,
                onMovePrevRequest: onMovePrev,
                onMoveNextRequest: onMoveNext
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShoesImgFun);


/***/ }),

/***/ 7374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7910);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);




const WatchImgFuc = ({ className , title , subTitle  })=>{
    const initilindex = {
        index: 0,
        isOpen: false
    };
    const { 0: photoIndex , 1: setPhotoIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initilindex);
    const onClickImg = (img, i)=>{
        setPhotoIndex({
            ...photoIndex,
            index: i,
            image: img,
            isOpen: true
        });
    };
    const onMoveNextALL = ()=>{
        console.log("WatchImgData.length", _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length);
        const next = (photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: next,
            image: test.img
        });
    };
    const onMovePrevALL = ()=>{
        console.log("WatchImgData.length", _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length);
        const prev = (photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length;
        const test = _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length];
        setPhotoIndex({
            ...photoIndex,
            index: prev,
            image: test.img
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length > 0 ? _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: className,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "overlay",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-portfolio",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "overlay-background",
                                        onClick: ()=>onClickImg(item.img, i)
                                        ,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            "aria-hidden": "true",
                                            className: "fa fa-plus"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        alt: "",
                                        className: "img-fluid blur-up lazyload",
                                        src: `/assets/images/${item.img}`
                                    })
                                ]
                            })
                        }),
                        title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "portfolio-text",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "head-text",
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "head-sub-text",
                                    children: subTitle
                                })
                            ]
                        })
                    ]
                }, i)
            ) : "",
            photoIndex.isOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default()), {
                mainSrc: `/assets/images${photoIndex === null || photoIndex === void 0 ? void 0 : photoIndex.image}`,
                nextSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData[(photoIndex.index + 1) % _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length].img}`,
                prevSrc: `/assets/images${_database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData[(photoIndex.index + _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length - 1) % _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length].img}`,
                imageTitle: photoIndex.index + 1 + "/" + _database__WEBPACK_IMPORTED_MODULE_2__.WatchImgData.length,
                onCloseRequest: ()=>setPhotoIndex({
                        ...photoIndex,
                        isOpen: false
                    })
                ,
                onMovePrevRequest: onMovePrevALL,
                onMoveNextRequest: onMoveNextALL
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WatchImgFuc);


/***/ }),

/***/ 2386:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7269);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7910);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Gallerys_allImgs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2306);
/* harmony import */ var _Gallerys_fashionImgs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2199);
/* harmony import */ var _Gallerys_bagsImgs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9133);
/* harmony import */ var _Gallerys_watchImg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7374);
/* harmony import */ var _Gallerys_shoesImg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2970);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([reactstrap__WEBPACK_IMPORTED_MODULE_2__]);
reactstrap__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const Basic = ({ className , title , subTitle , fluid  })=>{
    const { 0: activeTab , 1: setActiveTab  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('1');
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "portfolio-section fullwidth-portfolio masonray-sec zoom-gallery titles",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "filter-section",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                    fluid: true,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                            xs: "12",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Nav, {
                                tabs: true,
                                className: "filter-container isotopeFilters",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                        className: "list-inline filter",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                            className: activeTab == '1' ? 'active' : '',
                                            onClick: ()=>setActiveTab('1')
                                            ,
                                            children: "All"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                            className: activeTab == '2' ? 'active' : '',
                                            onClick: ()=>setActiveTab('2')
                                            ,
                                            children: "DESIGN"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                            className: activeTab == '3' ? 'active' : '',
                                            onClick: ()=>setActiveTab('3')
                                            ,
                                            children: "DEVELOPMENT"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                            className: activeTab == '4' ? 'active' : '',
                                            onClick: ()=>setActiveTab('4')
                                            ,
                                            children: "MARKETING"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                            className: activeTab == '5' ? 'active' : '',
                                            onClick: ()=>setActiveTab('5')
                                            ,
                                            children: "LEAD GENERATION"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: fluid || 'container',
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.TabContent, {
                    className: "isotopeContainer row",
                    activeTab: activeTab,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.TabPane, {
                            className: "row",
                            tabId: "1",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gallerys_allImgs__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: className,
                                title: title,
                                subTitle: subTitle
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.TabPane, {
                            className: "row",
                            tabId: "2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gallerys_fashionImgs__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                className: className,
                                title: title,
                                subTitle: subTitle
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.TabPane, {
                            className: "row",
                            tabId: "3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gallerys_bagsImgs__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                className: className,
                                title: title,
                                subTitle: subTitle
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.TabPane, {
                            className: "row",
                            tabId: "4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gallerys_watchImg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                className: className,
                                title: title,
                                subTitle: subTitle
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.TabPane, {
                            className: "row",
                            tabId: "5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gallerys_shoesImg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                className: className,
                                title: title,
                                subTitle: subTitle
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "pagination_sec",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "content_detail__pagination cdp",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "prev",
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        "aria-hidden": "true",
                                        className: "fa fa-angle-double-left"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "active cdp_i",
                                    href: "#",
                                    children: "1"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "cdp_i",
                                    href: "#",
                                    children: "2"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "cdp_i",
                                    href: "#",
                                    children: "3"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "next",
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        "aria-hidden": "true",
                                        className: "fa fa-angle-double-right"
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Basic);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7910:
/***/ ((module) => {


module.exports = {
    FeshionImgData: [
        {
            img: "/al-amana24.jpeg"
        },
        {
            img: "/arihas collection.jpeg"
        },
        {
            img: "/ayan fashion.jpeg"
        },
        {
            img: "/ben.rois.jpeg"
        }, 
    ],
    BagsImgData: [
        {
            img: "/chander konna.jpeg"
        },
        {
            img: "/creative creation.jpeg"
        },
        {
            img: "/emart.jpeg"
        },
        {
            img: "/food hatt.jpeg"
        }, 
    ],
    ShoesImgData: [
        {
            img: "/give & take.jpeg"
        },
        {
            img: "/hello guys.jpeg"
        },
        {
            img: "/home chef.jpeg"
        },
        {
            img: "/intex.jpeg"
        }, 
    ],
    WatchImgData: [
        {
            img: "/isha.jpeg"
        },
        {
            img: `/keya's beauty shop.jpeg`
        },
        {
            img: "/kozzyby.jpeg"
        },
        {
            img: "/noor.jpeg"
        }, 
    ],
    AllImgData: [
        {
            img: "/triangle.jpeg"
        },
        {
            img: "/travel kites.jpeg"
        },
        {
            img: "/tati polli.jpeg"
        },
        {
            img: "/sony lite.jpeg"
        },
        {
            img: "/shutki bajar.jpeg"
        },
        {
            img: "/shirt e.jpeg"
        },
        {
            img: "/s.jpeg"
        },
        {
            img: "/rupoboti.jpeg"
        },
        {
            img: "/priyoo sohor b-bariya.jpeg"
        },
        {
            img: "/polli rokomari.jpeg"
        },
        {
            img: "/pink s.jpeg"
        },
        {
            img: "/one touch.jpeg"
        }, 
    ],
    PortfolioDetail1Data: [
        {
            img: "/assets/images/2.jpg"
        },
        {
            img: "/assets/images/3.jpg"
        },
        {
            img: "/assets/images/5.jpg"
        },
        {
            img: "/assets/images/4.jpg"
        },
        {
            img: "/assets/images/5.jpg"
        },
        {
            img: "/assets/images/2.jpg"
        },
        {
            img: "/assets/images/3.jpg"
        }, 
    ],
    CreativeWrapperData: [
        {
            img: "../assets/images/1.jpg",
            title: "Lorem Ipsum",
            desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
        },
        {
            img: "../assets/images/2.jpg",
            title: "Lorem Ipsum",
            desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
        },
        {
            img: "../assets/images/3.jpg",
            title: "Lorem Ipsum",
            desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
        },
        {
            img: "../assets/images/4.jpg",
            title: "Lorem Ipsum",
            desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
        },
        {
            img: "../assets/images/5.jpg",
            title: "Lorem Ipsum",
            desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
        }, 
    ]
};


/***/ })

};
;